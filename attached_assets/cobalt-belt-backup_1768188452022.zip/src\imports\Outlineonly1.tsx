import imgOutlineonly1 from "figma:asset/ab5ac211c3c610f7bdfcd6d4a2384b98355ce7e5.png";

export default function Outlineonly() {
  return (
    <div className="relative size-full" data-name="outlineonly 1">
      <img alt="" className="block max-w-none size-full" height="1105" src={imgOutlineonly1} width="1355" />
    </div>
  );
}