/// <reference types="react-scripts" />
/// <reference types="vite/client" />
